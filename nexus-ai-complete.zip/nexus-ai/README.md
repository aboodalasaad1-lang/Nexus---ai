# Nexus AI - Your Intelligent AI Companion

Nexus AI is a cutting-edge AI-powered platform that combines intelligent conversation, creative image generation, professional video creation, and a vibrant community. Built with Next.js 15, React 19, and powered by GPT-4o and Claude 3.5.

## Features

- **AI Companion** - Super-intelligent chatbot with emotional intelligence, memory, and voice
- **Imagine** - Transform into 8+ personas with time travel effects
- **Edit Studio** - Professional AI-powered image editing tools
- **Video Generation** - Create stunning videos from text or images
- **Community** - Share creations, compete on leaderboards, discover trending content
- **AI Twin** - Create your digital twin (Premium)

## Tech Stack

### Frontend
- Next.js 15 + React 19
- TypeScript
- Tailwind CSS
- Framer Motion
- Three.js / React Three Fiber
- Zustand
- TanStack Query

### Backend
- Node.js + Express
- TypeScript
- PostgreSQL + Prisma
- Redis
- Socket.io
- Stripe / PayPal

### AI Services
- Python + FastAPI
- Stable Diffusion 3.5 / FLUX
- Runway Gen-3 / Pika 2.0
- InsightFace / Roop
- ElevenLabs Voice
- Whisper

### Infrastructure
- Docker + Kubernetes
- AWS S3 + CloudFront
- Cloudflare CDN
- Vercel (Frontend)

## Quick Start

### Prerequisites
- Node.js 20+
- Python 3.10+
- Docker & Docker Compose
- PostgreSQL 16
- Redis 7

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/nexus-ai.git
cd nexus-ai
```

2. Set up environment variables
```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
# Edit the .env files with your API keys
```

3. Start with Docker Compose
```bash
docker-compose up -d
```

4. Run database migrations
```bash
cd backend
npx prisma migrate dev
npx prisma generate
```

5. Start development servers
```bash
# Terminal 1 - Backend
cd backend
npm run dev

# Terminal 2 - Frontend
cd frontend
npm run dev

# Terminal 3 - AI Services (optional)
cd ai-services
python3 -m uvicorn main:app --reload
```

### Deployment

#### Kubernetes
```bash
kubectl apply -f infra/k8s/namespace.yaml
kubectl apply -f infra/k8s/secrets.yaml
kubectl apply -f infra/k8s/configmap.yaml
kubectl apply -f infra/k8s/postgres-deployment.yaml
kubectl apply -f infra/k8s/redis-deployment.yaml
kubectl apply -f infra/k8s/backend-deployment.yaml
kubectl apply -f infra/k8s/frontend-deployment.yaml
kubectl apply -f infra/k8s/ingress.yaml
```

#### Vercel (Frontend)
```bash
cd frontend
vercel --prod
```

## API Documentation

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/refresh` - Refresh token

### Chat
- `POST /api/chat/message` - Send message to AI
- `GET /api/chat/history/:chatId` - Get chat history
- `POST /api/chat/voice` - Generate voice response

### Imagine
- `POST /api/imagine/generate` - Generate persona image
- `GET /api/imagine/personas` - List available personas

### Edit
- `POST /api/edit/process` - Process image with tool
- `GET /api/edit/tools` - List editing tools

### Video
- `POST /api/video/generate` - Generate video from text
- `POST /api/video/from-image` - Generate video from image

### Payments
- `GET /api/payments/plans` - Get subscription plans
- `POST /api/payments/subscribe` - Create subscription
- `POST /api/payments/buy-credits` - Buy credits

## Pricing

| Plan | Price | Features |
|------|-------|----------|
| Free | $0 | 20 messages/day, 3 images/month |
| Pro | $9.99/mo | Unlimited messages, 100 images, voice |
| Premium | $19.99/mo | Everything + AI Twin, videos, API |

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

- Email: support@nexus-ai.com
- Discord: [Join our community](https://discord.gg/nexus-ai)
- Twitter: [@NexusAI](https://twitter.com/nexusai)

---

Made with AI for humans worldwide.