from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import StreamingResponse
import io
import numpy as np
from PIL import Image
import torch
from diffusers import StableDiffusionPipeline, StableDiffusionImg2ImgPipeline
import os

app = FastAPI(title="Nexus AI Services", version="1.0.0")

# Load models (lazy loading on first request)
sd_pipeline = None
img2img_pipeline = None

def get_sd_pipeline():
    global sd_pipeline
    if sd_pipeline is None:
        model_id = os.getenv("SD_MODEL", "stabilityai/stable-diffusion-xl-base-1.0")
        sd_pipeline = StableDiffusionPipeline.from_pretrained(
            model_id,
            torch_dtype=torch.float16,
            use_safetensors=True,
        )
        sd_pipeline = sd_pipeline.to("cuda")
    return sd_pipeline

def get_img2img_pipeline():
    global img2img_pipeline
    if img2img_pipeline is None:
        model_id = os.getenv("SD_MODEL", "stabilityai/stable-diffusion-xl-base-1.0")
        img2img_pipeline = StableDiffusionImg2ImgPipeline.from_pretrained(
            model_id,
            torch_dtype=torch.float16,
            use_safetensors=True,
        )
        img2img_pipeline = img2img_pipeline.to("cuda")
    return img2img_pipeline

@app.get("/health")
async def health():
    return {"status": "ok", "gpu": torch.cuda.is_available(), "gpu_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none"}

@app.post("/generate/image")
async def generate_image(prompt: str, width: int = 1024, height: int = 1024, steps: int = 30):
    try:
        pipeline = get_sd_pipeline()
        image = pipeline(
            prompt,
            num_inference_steps=steps,
            width=width,
            height=height,
            guidance_scale=7.5,
        ).images[0]

        img_byte_arr = io.BytesIO()
        image.save(img_byte_arr, format='PNG')
        img_byte_arr.seek(0)

        return StreamingResponse(img_byte_arr, media_type="image/png")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/generate/image-to-image")
async def image_to_image(file: UploadFile = File(...), prompt: str = "", strength: float = 0.75):
    try:
        contents = await file.read()
        init_image = Image.open(io.BytesIO(contents)).convert("RGB")
        init_image = init_image.resize((1024, 1024))

        pipeline = get_img2img_pipeline()
        image = pipeline(
            prompt=prompt,
            image=init_image,
            strength=strength,
            num_inference_steps=30,
            guidance_scale=7.5,
        ).images[0]

        img_byte_arr = io.BytesIO()
        image.save(img_byte_arr, format='PNG')
        img_byte_arr.seek(0)

        return StreamingResponse(img_byte_arr, media_type="image/png")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/edit/remove-background")
async def remove_background(file: UploadFile = File(...)):
    # Integration with rembg or similar
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert("RGBA")
        # Placeholder - integrate with actual background removal
        img_byte_arr = io.BytesIO()
        image.save(img_byte_arr, format='PNG')
        img_byte_arr.seek(0)
        return StreamingResponse(img_byte_arr, media_type="image/png")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/face/swap")
async def face_swap(source: UploadFile = File(...), target: UploadFile = File(...)):
    # Integration with InsightFace / Roop
    try:
        # Placeholder implementation
        contents = await target.read()
        image = Image.open(io.BytesIO(contents))
        img_byte_arr = io.BytesIO()
        image.save(img_byte_arr, format='PNG')
        img_byte_arr.seek(0)
        return StreamingResponse(img_byte_arr, media_type="image/png")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)