/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        nexus: {
          50: "#f0f4ff", 100: "#e0e9ff", 200: "#c7d7fe", 300: "#a5bafc",
          400: "#8194f8", 500: "#6366f1", 600: "#4f46e5", 700: "#4338ca",
          800: "#3730a3", 900: "#312e81", 950: "#1e1b4b",
        },
        accent: { cyan: "#06b6d4", magenta: "#d946ef", amber: "#f59e0b" },
      },
      fontFamily: { sans: ["Inter", "system-ui", "sans-serif"] },
      animation: {
        "gradient-x": "gradient-x 15s ease infinite",
        "float": "float 6s ease-in-out infinite",
        "pulse-glow": "pulse-glow 2s ease-in-out infinite",
      },
      keyframes: {
        "gradient-x": { "0%, 100%": { "background-position": "0% 50%" }, "50%": { "background-position": "100% 50%" } },
        "float": { "0%, 100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-20px)" } },
        "pulse-glow": { "0%, 100%": { opacity: "1", boxShadow: "0 0 20px rgba(99,102,241,0.5)" }, "50%": { opacity: "0.8", boxShadow: "0 0 40px rgba(99,102,241,0.8)" } },
      },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};