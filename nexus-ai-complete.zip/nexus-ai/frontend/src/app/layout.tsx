import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { QueryProvider } from "@/lib/query-provider";
import { AuthProvider } from "@/components/auth-provider";
import { Toaster } from "react-hot-toast";
import { Analytics } from "@vercel/analytics/react";

const inter = Inter({ subsets: ["latin", "arabic"] });

export const metadata: Metadata = {
  title: "Nexus AI - Your Intelligent AI Companion",
  description: "Nexus AI is the world's most advanced AI companion. Chat, create images, generate videos, and transform your digital experience.",
  keywords: ["AI", "companion", "chatbot", "image generation", "video generation", "face swap", "AI twin"],
  authors: [{ name: "Nexus AI Team" }],
  openGraph: {
    title: "Nexus AI - Your Intelligent AI Companion",
    description: "The future of AI interaction is here. Chat, create, and transform with Nexus AI.",
    type: "website", locale: "en_US", images: ["/og-image.jpg"],
  },
  twitter: {
    card: "summary_large_image", title: "Nexus AI",
    description: "Your Intelligent AI Companion", images: ["/og-image.jpg"],
  },
  manifest: "/manifest.json",
  icons: { icon: "/favicon.ico", apple: "/apple-touch-icon.png" },
};

export const viewport: Viewport = {
  themeColor: "#1e1b4b", width: "device-width", initialScale: 1, maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" dir="ltr" suppressHydrationWarning>
      <body className={inter.className}>
        <QueryProvider><AuthProvider>
          {children}
          <Toaster position="top-right" toastOptions={{
            style: { background: "#1a1a2e", color: "#fff", border: "1px solid rgba(99,102,241,0.3)" },
          }} />
        </AuthProvider></QueryProvider>
        <Analytics />
      </body>
    </html>
  );
}