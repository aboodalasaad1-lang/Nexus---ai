"use client";

import { ImagineEngine } from "@/components/imagine/imagine-engine";

export default function ImaginePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0f] via-[#1a1a2e] to-[#0f0f1a] pt-20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 className="section-title text-center mb-4">Imagine Yourself</h1>
        <p className="text-white/60 text-center text-lg mb-12 max-w-2xl mx-auto">
          Upload your photo and transform into 8+ unique personas. Travel through time, become a superhero, or live the luxury life.
        </p>
        <ImagineEngine />
      </div>
    </div>
  );
}