"use client";

import { CommunityFeed } from "@/components/community/community-feed";
import { Leaderboard } from "@/components/community/leaderboard";

export default function CommunityPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0f] via-[#1a1a2e] to-[#0f0f1a] pt-20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h1 className="section-title mb-8">AI Gallery</h1>
            <CommunityFeed />
          </div>
          <div className="lg:col-span-1">
            <h2 className="text-2xl font-bold text-white mb-6">Leaderboard</h2>
            <Leaderboard />
          </div>
        </div>
      </div>
    </div>
  );
}