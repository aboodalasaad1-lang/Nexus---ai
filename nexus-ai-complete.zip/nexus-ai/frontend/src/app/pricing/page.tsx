"use client";

import { PricingSection } from "@/components/pricing/pricing-section";

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0f] via-[#1a1a2e] to-[#0f0f1a] pt-20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 className="section-title text-center mb-4">Choose Your Plan</h1>
        <p className="text-white/60 text-center text-lg mb-12 max-w-2xl mx-auto">
          Start free and upgrade when you need more power. No credit card required for the free tier.
        </p>
        <PricingSection />
      </div>
    </div>
  );
}