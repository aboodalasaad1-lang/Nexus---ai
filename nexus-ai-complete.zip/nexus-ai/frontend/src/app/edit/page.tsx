"use client";

import { EditStudio } from "@/components/edit/edit-studio";

export default function EditPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0f] via-[#1a1a2e] to-[#0f0f1a] pt-20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 className="section-title text-center mb-4">Edit Studio</h1>
        <p className="text-white/60 text-center text-lg mb-12 max-w-2xl mx-auto">
          Professional AI-powered editing tools. Remove backgrounds, enhance quality, change clothes, and create cinematic effects.
        </p>
        <EditStudio />
      </div>
    </div>
  );
}