"use client";

import { ChatInterface } from "@/components/chat/chat-interface";
import { AICompanion3D } from "@/components/3d/ai-companion-3d";

export default function ChatPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0f] via-[#1a1a2e] to-[#0f0f1a]">
      <div className="flex h-screen">
        <div className="hidden lg:flex w-1/3 border-r border-white/10 relative">
          <AICompanion3D />
          <div className="absolute bottom-8 left-8 right-8">
            <div className="glass-card p-4 text-center">
              <p className="text-white/70 text-sm">Your AI Companion is listening...</p>
              <div className="flex justify-center gap-1 mt-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="w-1 bg-nexus-500 rounded-full animate-pulse"
                    style={{ height: `${Math.random() * 20 + 10}px`, animationDelay: `${i * 0.1}s` }} />
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="flex-1"><ChatInterface /></div>
      </div>
    </div>
  );
}