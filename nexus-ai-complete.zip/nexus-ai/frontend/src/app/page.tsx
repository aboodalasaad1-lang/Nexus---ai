"use client";

import { motion } from "framer-motion";
import { HeroSection } from "@/components/hero-section";
import { FeaturesGrid } from "@/components/features-grid";
import { AICompanionPreview } from "@/components/3d/ai-companion-preview";
import { ImagineShowcase } from "@/components/imagine/imagine-showcase";
import { PricingSection } from "@/components/pricing/pricing-section";
import { CommunityPreview } from "@/components/community/community-preview";
import { Footer } from "@/components/footer";
import { Navbar } from "@/components/navbar";

export default function HomePage() {
  return (
    <main className="relative min-h-screen overflow-hidden">
      <Navbar />
      <HeroSection />
      <motion.section initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="section-title text-center mb-16">Meet Your AI Companion</h2>
          <AICompanionPreview />
        </div>
      </motion.section>
      <motion.section initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="section-title text-center mb-16">Imagine Anything</h2>
          <ImagineShowcase />
        </div>
      </motion.section>
      <FeaturesGrid />
      <motion.section initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="section-title text-center mb-16">Join the Community</h2>
          <CommunityPreview />
        </div>
      </motion.section>
      <PricingSection />
      <Footer />
    </main>
  );
}