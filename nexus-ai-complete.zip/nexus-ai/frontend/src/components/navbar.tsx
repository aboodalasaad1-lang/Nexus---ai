"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { Sparkles, Menu, X, Coins, User } from "lucide-react";
import { useAuthStore } from "@/store/auth-store";

const navLinks = [
  { href: "/chat", label: "Chat" },
  { href: "/imagine", label: "Imagine" },
  { href: "/edit", label: "Edit" },
  { href: "/community", label: "Community" },
  { href: "/pricing", label: "Pricing" },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, isAuthenticated } = useAuthStore();

  return (
    <motion.nav initial={{ y: -100 }} animate={{ y: 0 }} className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-nexus-500 to-accent-cyan flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text">Nexus AI</span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href} className="text-white/70 hover:text-white transition-colors text-sm font-medium">{link.label}</Link>
            ))}
          </div>
          <div className="hidden md:flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <div className="flex items-center gap-2 glass-card px-3 py-1.5 rounded-full">
                  <Coins className="w-4 h-4 text-amber-400" />
                  <span className="text-white text-sm font-medium">{user?.credits || 0}</span>
                </div>
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-nexus-500 to-accent-cyan flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
              </>
            ) : (
              <>
                <Link href="/login" className="text-white/70 hover:text-white transition-colors text-sm font-medium">Sign In</Link>
                <Link href="/register" className="glow-button text-sm py-2 px-4">Get Started</Link>
              </>
            )}
          </div>
          <button onClick={() => setIsOpen(!isOpen)} className="md:hidden p-2 text-white/70 hover:text-white">
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>
      <AnimatePresence>
        {isOpen && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="md:hidden glass-card border-t border-white/10">
            <div className="px-4 py-4 space-y-2">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href} onClick={() => setIsOpen(false)} className="block py-2 text-white/70 hover:text-white transition-colors">{link.label}</Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}