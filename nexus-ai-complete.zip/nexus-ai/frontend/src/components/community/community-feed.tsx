"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Heart, MessageCircle, Share2, Flag, Crown } from "lucide-react";

const posts = [
  { id: 1, user: "Alex Chen", avatar: "A", title: "My Millionaire Persona", likes: 2341, comments: 156, persona: "Millionaire", featured: true },
  { id: 2, user: "Sarah Miller", avatar: "S", title: "Superhero Mode Activated", likes: 1892, comments: 98, persona: "Superhero", featured: false },
  { id: 3, user: "James Wilson", avatar: "J", title: "Space Explorer 2050", likes: 3156, comments: 234, persona: "Astronaut", featured: true },
  { id: 4, user: "Emma Davis", avatar: "E", title: "Royal Treatment", likes: 1234, comments: 87, persona: "Royal", featured: false },
  { id: 5, user: "Michael Brown", avatar: "M", title: "Future Me", likes: 2876, comments: 198, persona: "Time Travel", featured: true },
  { id: 6, user: "Lisa Anderson", avatar: "L", title: "Fantasy World", likes: 1567, comments: 123, persona: "Fantasy", featured: false },
];

export function CommunityFeed() {
  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set());

  const toggleLike = (id: number) => {
    setLikedPosts((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {posts.map((post, index) => (
        <motion.div key={post.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}
          className="glass-card rounded-2xl overflow-hidden group">
          <div className="relative aspect-square bg-gradient-to-br from-nexus-900/50 to-accent-cyan/20">
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10" />
            {post.featured && (
              <div className="absolute top-3 right-3 z-20 bg-amber-500/80 px-2 py-1 rounded-full flex items-center gap-1">
                <Crown className="w-3 h-3 text-white" />
                <span className="text-xs text-white font-medium">Featured</span>
              </div>
            )}
            <div className="absolute top-3 left-3 z-20 flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-sm font-bold text-white">{post.avatar}</div>
              <span className="text-white text-sm font-medium">{post.user}</span>
            </div>
            <div className="absolute bottom-3 left-3 right-3 z-20">
              <h4 className="text-white font-semibold">{post.title}</h4>
              <span className="text-white/60 text-xs">{post.persona}</span>
            </div>
          </div>
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button onClick={() => toggleLike(post.id)} className="flex items-center gap-1 text-white/60 hover:text-red-400 transition-colors">
                <Heart className={`w-5 h-5 ${likedPosts.has(post.id) ? "fill-red-400 text-red-400" : ""}`} />
                <span className="text-sm">{post.likes + (likedPosts.has(post.id) ? 1 : 0)}</span>
              </button>
              <button className="flex items-center gap-1 text-white/60 hover:text-nexus-400 transition-colors">
                <MessageCircle className="w-5 h-5" />
                <span className="text-sm">{post.comments}</span>
              </button>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 rounded-lg hover:bg-white/10 transition-colors text-white/60"><Share2 className="w-4 h-4" /></button>
              <button className="p-2 rounded-lg hover:bg-white/10 transition-colors text-white/60"><Flag className="w-4 h-4" /></button>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}