"use client";

import { motion } from "framer-motion";
import { Heart, MessageCircle, Users, TrendingUp } from "lucide-react";

const stats = [
  { label: "Active Users", value: "50K+", icon: Users },
  { label: "AI Creations", value: "1M+", icon: TrendingUp },
  { label: "Daily Likes", value: "500K+", icon: Heart },
  { label: "Comments", value: "100K+", icon: MessageCircle },
];

export function CommunityPreview() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
      <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="glass-card p-8 rounded-3xl">
        <h3 className="text-2xl font-bold text-white mb-6">Community Stats</h3>
        <div className="grid grid-cols-2 gap-4">
          {stats.map((stat, index) => (
            <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }} className="glass-card p-4 rounded-xl text-center">
              <stat.icon className="w-6 h-6 text-nexus-400 mx-auto mb-2" />
              <div className="text-2xl font-bold gradient-text">{stat.value}</div>
              <div className="text-white/60 text-sm">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </motion.div>
      <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="space-y-4">
        <div className="glass-card p-6 rounded-2xl">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-nexus-500 to-accent-cyan flex items-center justify-center text-white font-bold">J</div>
            <div>
              <p className="text-white font-medium">James Wilson</p>
              <p className="text-white/40 text-sm">Just created an amazing Astronaut persona!</p>
            </div>
          </div>
          <div className="aspect-video rounded-xl bg-gradient-to-br from-nexus-900/50 to-accent-cyan/20 mb-4" />
          <div className="flex items-center gap-4 text-white/60">
            <span className="flex items-center gap-1"><Heart className="w-4 h-4" /> 3.2K</span>
            <span className="flex items-center gap-1"><MessageCircle className="w-4 h-4" /> 234</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}