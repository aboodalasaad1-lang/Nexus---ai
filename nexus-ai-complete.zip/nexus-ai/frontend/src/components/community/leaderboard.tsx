"use client";

import { motion } from "framer-motion";
import { Trophy, Medal, Crown, TrendingUp } from "lucide-react";

const leaders = [
  { rank: 1, name: "James Wilson", points: 15234, avatar: "J", trend: "up" },
  { rank: 2, name: "Sarah Miller", points: 12890, avatar: "S", trend: "up" },
  { rank: 3, name: "Alex Chen", points: 11567, avatar: "A", trend: "down" },
  { rank: 4, name: "Emma Davis", points: 9876, avatar: "E", trend: "up" },
  { rank: 5, name: "Michael Brown", points: 8543, avatar: "M", trend: "same" },
  { rank: 6, name: "Lisa Anderson", points: 7234, avatar: "L", trend: "up" },
  { rank: 7, name: "David Lee", points: 6789, avatar: "D", trend: "down" },
  { rank: 8, name: "Rachel Green", points: 5432, avatar: "R", trend: "up" },
];

const getRankIcon = (rank: number) => {
  switch (rank) {
    case 1: return <Crown className="w-5 h-5 text-amber-400" />;
    case 2: return <Medal className="w-5 h-5 text-gray-300" />;
    case 3: return <Medal className="w-5 h-5 text-amber-600" />;
    default: return <span className="text-white/40 text-sm font-mono">#{rank}</span>;
  }
};

const getRankBg = (rank: number) => {
  switch (rank) {
    case 1: return "bg-amber-500/20 border-amber-500/30";
    case 2: return "bg-gray-400/20 border-gray-400/30";
    case 3: return "bg-amber-700/20 border-amber-700/30";
    default: return "bg-white/5 border-white/10";
  }
};

export function Leaderboard() {
  return (
    <div className="glass-card rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-6">
        <Trophy className="w-6 h-6 text-amber-400" />
        <h3 className="text-xl font-bold text-white">Top Creators</h3>
      </div>
      <div className="space-y-3">
        {leaders.map((leader, index) => (
          <motion.div key={leader.rank} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.05 }}
            className={`flex items-center gap-3 p-3 rounded-xl border ${getRankBg(leader.rank)}`}>
            <div className="w-8 flex justify-center">{getRankIcon(leader.rank)}</div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-nexus-500 to-accent-cyan flex items-center justify-center text-white font-bold text-sm">{leader.avatar}</div>
            <div className="flex-1">
              <p className="text-white font-medium text-sm">{leader.name}</p>
              <p className="text-white/40 text-xs">{leader.points.toLocaleString()} points</p>
            </div>
            <TrendingUp className={`w-4 h-4 ${leader.trend === "up" ? "text-green-400" : leader.trend === "down" ? "text-red-400" : "text-white/40"}`} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}