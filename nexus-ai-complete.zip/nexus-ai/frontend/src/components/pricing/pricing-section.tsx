"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Check, Zap, Crown, Star, ArrowRight } from "lucide-react";

const plans = [
  {
    name: "Free", price: "$0", period: "/month", description: "Perfect for getting started", icon: Star,
    color: "from-gray-500 to-gray-600",
    features: ["20 AI messages per day", "3 AI images per month", "Basic editing tools", "Community access", "Watermark on outputs", "Standard support"],
    limitations: ["No video generation", "No voice features", "No AI Twin"],
    cta: "Get Started Free", popular: false,
  },
  {
    name: "Pro", price: "$9.99", period: "/month", description: "For serious creators", icon: Zap,
    color: "from-nexus-500 to-nexus-600",
    features: ["Unlimited AI messages", "100 AI images per month", "Remove watermark", "AI voice responses", "All editing tools", "Priority processing", "5 video generations"],
    limitations: ["No AI Twin", "No custom personas"],
    cta: "Upgrade to Pro", popular: true,
  },
  {
    name: "Premium", price: "$19.99", period: "/month", description: "The ultimate experience", icon: Crown,
    color: "from-amber-500 to-amber-600",
    features: ["Everything in Pro", "500 AI images per month", "Unlimited video generation", "AI Twin creation", "Custom AI personas", "Fastest processing", "API access", "Dedicated support"],
    limitations: [],
    cta: "Go Premium", popular: false,
  },
];

export function PricingSection() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  return (
    <section className="py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
          <h2 className="section-title">Simple, Transparent Pricing</h2>
          <p className="text-white/60 max-w-2xl mx-auto">Choose the plan that fits your needs. Upgrade or downgrade anytime.</p>
          <div className="flex items-center justify-center gap-4 mt-8">
            <button onClick={() => setBillingCycle("monthly")} className={`px-4 py-2 rounded-lg transition-colors ${billingCycle === "monthly" ? "bg-nexus-600 text-white" : "text-white/60 hover:text-white"}`}>Monthly</button>
            <button onClick={() => setBillingCycle("yearly")} className={`px-4 py-2 rounded-lg transition-colors ${billingCycle === "yearly" ? "bg-nexus-600 text-white" : "text-white/60 hover:text-white"}`}>Yearly <span className="text-green-400 text-sm">Save 20%</span></button>
          </div>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div key={plan.name} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }}
              className={`relative glass-card rounded-3xl p-8 ${plan.popular ? "ring-2 ring-nexus-500" : ""}`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-nexus-600 text-white px-4 py-1 rounded-full text-sm font-medium">Most Popular</div>
                </div>
              )}
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-6`}>
                <plan.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
              <p className="text-white/60 text-sm mb-4">{plan.description}</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-white">{billingCycle === "yearly" ? `$${(parseFloat(plan.price.replace("$", "")) * 0.8).toFixed(2)}` : plan.price}</span>
                <span className="text-white/40">{plan.period}</span>
              </div>
              <div className="space-y-3 mb-8">
                {plan.features.map((feature) => (
                  <div key={feature} className="flex items-center gap-3"><Check className="w-5 h-5 text-green-400 flex-shrink-0" /><span className="text-white/80 text-sm">{feature}</span></div>
                ))}
                {plan.limitations.map((limitation) => (
                  <div key={limitation} className="flex items-center gap-3 opacity-50">
                    <div className="w-5 h-5 rounded-full border border-white/30 flex items-center justify-center text-white/30 text-xs">×</div>
                    <span className="text-white/40 text-sm">{limitation}</span>
                  </div>
                ))}
              </div>
              <button className={`w-full py-3 rounded-xl font-semibold transition-all duration-300 flex items-center justify-center gap-2 ${plan.popular ? "bg-nexus-600 text-white hover:bg-nexus-500 glow-button" : "bg-white/10 text-white hover:bg-white/20"}`}>
                {plan.cta}<ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}