"use client";

import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Environment, Float, MeshDistortMaterial, Sphere } from "@react-three/drei";
import { motion } from "framer-motion";

function AIOrb() {
  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
      <Sphere args={[1, 64, 64]} scale={1.5}>
        <MeshDistortMaterial color="#6366f1" attach="material" distort={0.4} speed={2} roughness={0.2} metalness={0.8} />
      </Sphere>
      <Sphere args={[1, 64, 64]} scale={1.6}>
        <meshBasicMaterial color="#6366f1" transparent opacity={0.1} wireframe />
      </Sphere>
      <pointLight position={[10, 10, 10]} intensity={1} color="#6366f1" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#06b6d4" />
    </Float>
  );
}

function Particles() {
  const particles = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    position: [(Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10] as [number, number, number],
    size: Math.random() * 0.05 + 0.01,
  }));
  return (
    <>
      {particles.map((particle) => (
        <mesh key={particle.id} position={particle.position}>
          <sphereGeometry args={[particle.size, 8, 8]} />
          <meshBasicMaterial color="#6366f1" transparent opacity={0.6} />
        </mesh>
      ))}
    </>
  );
}

export function AICompanion3D() {
  return (
    <div className="w-full h-full relative">
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <AIOrb />
          <Particles />
          <Environment preset="city" />
          <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={0.5} />
        </Suspense>
      </Canvas>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }}
        className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none">
        <div className="w-32 h-32 rounded-full bg-nexus-500/20 blur-3xl" />
      </motion.div>
    </div>
  );
}