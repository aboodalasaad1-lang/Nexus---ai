"use client";

import { motion } from "framer-motion";
import { Sparkles, MessageCircle, Brain, Heart } from "lucide-react";

const features = [
  { icon: Brain, title: "Super Intelligence", description: "Powered by GPT-4o and Claude 3.5 with advanced reasoning" },
  { icon: Heart, title: "Emotional Intelligence", description: "Understands your mood and adapts responses accordingly" },
  { icon: MessageCircle, title: "Multi-Language", description: "Fluent in 50+ languages including Arabic, English, Chinese" },
  { icon: Sparkles, title: "Creative Genius", description: "Generates images, videos, ideas, and creative content" },
];

export function AICompanionPreview() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
      <motion.div initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-nexus-500/20 to-accent-cyan/20 rounded-3xl blur-3xl" />
          <div className="relative glass-card p-8 rounded-3xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-nexus-500 to-accent-cyan flex items-center justify-center">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white">Nexus AI</h3>
                <p className="text-white/60">Your Intelligent Companion</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="glass-card p-4 rounded-xl bg-white/5"><p className="text-white/80 text-sm">"How can I help you today?"</p></div>
              <div className="glass-card p-4 rounded-xl bg-nexus-600/20 ml-8"><p className="text-white/80 text-sm">"I need a creative business idea for 2026"</p></div>
              <div className="glass-card p-4 rounded-xl bg-white/5"><p className="text-white/80 text-sm">"Here are 5 innovative AI-powered business ideas for 2026..."</p></div>
            </div>
          </div>
        </div>
      </motion.div>
      <motion.div initial={{ opacity: 0, x: 50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.2 }}
        className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {features.map((feature, index) => (
          <motion.div key={feature.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }} className="feature-card">
            <div className="w-12 h-12 rounded-xl bg-nexus-600/30 flex items-center justify-center mb-4">
              <feature.icon className="w-6 h-6 text-nexus-400" />
            </div>
            <h4 className="font-semibold text-white mb-2">{feature.title}</h4>
            <p className="text-white/60 text-sm">{feature.description}</p>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}