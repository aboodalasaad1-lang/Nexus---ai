"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight, Sparkles, Zap, Globe } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-nexus-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent-cyan/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-nexus-600/10 rounded-full blur-3xl" />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 text-center">
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
          <div className="inline-flex items-center gap-2 glass-card px-4 py-2 rounded-full mb-8">
            <Sparkles className="w-4 h-4 text-nexus-400" />
            <span className="text-white/80 text-sm">The Future of AI is Here</span>
          </div>
          <h1 className="text-5xl sm:text-7xl lg:text-8xl font-bold mb-6 leading-tight">
            <span className="gradient-text">Nexus AI</span><br />
            <span className="text-white">Your Intelligent</span><br />
            <span className="text-white/80">Companion</span>
          </h1>
          <p className="text-xl text-white/60 max-w-2xl mx-auto mb-10">
            Chat, create, and transform with the world's most advanced AI. Generate images, videos, and experience emotional intelligence like never before.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Link href="/chat" className="glow-button text-lg px-8 py-4 inline-flex items-center gap-2">
              <Zap className="w-5 h-5" />Start Chatting<ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="/imagine" className="glass-card px-8 py-4 rounded-xl text-white font-semibold hover:bg-white/10 transition-all duration-300 inline-flex items-center gap-2">
              <Sparkles className="w-5 h-5" />Try Imagine
            </Link>
          </div>
          <div className="flex items-center justify-center gap-8 text-white/40 text-sm">
            <div className="flex items-center gap-2"><Globe className="w-4 h-4" /><span>50+ Languages</span></div>
            <div className="flex items-center gap-2"><Zap className="w-4 h-4" /><span>Real-time AI</span></div>
            <div className="flex items-center gap-2"><Sparkles className="w-4 h-4" /><span>GPT-4o Powered</span></div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}