"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Square } from "lucide-react";

interface VoiceRecorderProps { onStop: () => void; }

export function VoiceRecorder({ onStop }: VoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const bars = 20;
    const barWidth = canvas.width / bars;

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < bars; i++) {
        const height = Math.random() * canvas.height * (isRecording ? 0.8 : 0.2);
        const x = i * barWidth;
        const y = (canvas.height - height) / 2;
        const gradient = ctx.createLinearGradient(0, y, 0, y + height);
        gradient.addColorStop(0, "rgba(99, 102, 241, 0.8)");
        gradient.addColorStop(1, "rgba(6, 182, 212, 0.8)");
        ctx.fillStyle = gradient;
        ctx.fillRect(x + 1, y, barWidth - 2, height);
      }
      animationRef.current = requestAnimationFrame(animate);
    };
    animate();
    setIsRecording(true);
    return () => { if (animationRef.current) cancelAnimationFrame(animationRef.current); };
  }, [isRecording]);

  const handleStop = () => { setIsRecording(false); onStop(); };

  return (
    <div className="flex items-center gap-2">
      <canvas ref={canvasRef} width={100} height={40} className="rounded-lg bg-white/5" />
      <motion.button whileTap={{ scale: 0.9 }} onClick={handleStop}
        className="p-3 rounded-xl bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors border border-red-500/30">
        <Square className="w-5 h-5" />
      </motion.button>
    </div>
  );
}