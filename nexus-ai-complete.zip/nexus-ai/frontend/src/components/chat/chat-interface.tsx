"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useChatStore } from "@/store/chat-store";
import { Send, Mic, Image, Video, Sparkles, Loader2, Volume2, VolumeX } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import toast from "react-hot-toast";
import { ChatBubble } from "./chat-bubble";
import { SuggestedActions } from "./suggested-actions";
import { VoiceRecorder } from "./voice-recorder";

export function ChatInterface() {
  const [input, setInput] = useState("");
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { messages, addMessage, setTyping, isTyping } = useChatStore();

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  useEffect(() => scrollToBottom(), [messages]);

  const sendMessage = useMutation({
    mutationFn: async (content: string) => {
      const response = await api.post("/chat/message", {
        content, chatId: "default", voiceEnabled, voiceGender: "female",
      });
      return response.data;
    },
    onMutate: (content) => {
      addMessage({ id: crypto.randomUUID(), role: "USER", content, createdAt: new Date() });
      setInput("");
      setTyping(true);
    },
    onSuccess: (data) => {
      addMessage(data.message);
      setTyping(false);
      if (data.message.audioUrl) {
        const audio = new Audio(data.message.audioUrl);
        audio.play().catch(() => {});
      }
    },
    onError: () => { setTyping(false); toast.error("Failed to get response. Please try again."); },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || sendMessage.isPending) return;
    sendMessage.mutate(input.trim());
  };

  const handleSuggestion = (suggestion: string) => sendMessage.mutate(suggestion);
  const handleImageUpload = () => toast("Image upload feature coming soon!", { icon: "🖼️" });
  const handleVideoRequest = () => toast("Video generation feature coming soon!", { icon: "🎬" });

  return (
    <div className="flex flex-col h-full">
      <div className="glass-card border-b border-white/10 p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-nexus-500 to-accent-cyan flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white">Nexus AI</h3>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-xs text-white/60">Online</span>
            </div>
          </div>
        </div>
        <button onClick={() => setVoiceEnabled(!voiceEnabled)}
          className={`p-2 rounded-lg transition-colors ${voiceEnabled ? "bg-nexus-600 text-white" : "bg-white/5 text-white/60 hover:bg-white/10"}`}>
          {voiceEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {messages.length === 0 && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-12">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-nexus-500 to-accent-cyan flex items-center justify-center animate-pulse-glow">
                <Sparkles className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Welcome to Nexus AI</h3>
              <p className="text-white/60 max-w-md mx-auto">
                I am your intelligent AI companion. I can chat, generate images, create videos, and help with anything you need.
              </p>
              <SuggestedActions onSelect={handleSuggestion} />
            </motion.div>
          )}
          {messages.map((msg, index) => (
            <ChatBubble key={msg.id} message={msg} isLatest={index === messages.length - 1} />
          ))}
          {isTyping && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="chat-bubble-ai flex items-center gap-2 w-fit">
              <Loader2 className="w-4 h-4 animate-spin text-nexus-400" />
              <span className="text-white/60 text-sm">Nexus is thinking...</span>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      <div className="glass-card border-t border-white/10 p-4">
        <form onSubmit={handleSubmit} className="flex items-end gap-2">
          <div className="flex gap-2 mb-2">
            <button type="button" onClick={handleImageUpload} className="p-2 rounded-lg bg-white/5 text-white/60 hover:bg-white/10 transition-colors">
              <Image className="w-5 h-5" />
            </button>
            <button type="button" onClick={handleVideoRequest} className="p-2 rounded-lg bg-white/5 text-white/60 hover:bg-white/10 transition-colors">
              <Video className="w-5 h-5" />
            </button>
          </div>
          <div className="flex-1 relative">
            <textarea value={input} onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSubmit(e); } }}
              placeholder="Message Nexus AI..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-nexus-500/50 resize-none max-h-32"
              rows={1} style={{ minHeight: "48px" }} />
          </div>
          {isRecording ? <VoiceRecorder onStop={() => setIsRecording(false)} /> : (
            <button type="button" onClick={() => setIsRecording(true)} className="p-3 rounded-xl bg-white/5 text-white/60 hover:bg-white/10 transition-colors">
              <Mic className="w-5 h-5" />
            </button>
          )}
          <button type="submit" disabled={!input.trim() || sendMessage.isPending}
            className="p-3 rounded-xl bg-nexus-600 text-white hover:bg-nexus-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
            {sendMessage.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          </button>
        </form>
      </div>
    </div>
  );
}