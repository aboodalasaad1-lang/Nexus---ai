"use client";

import { motion } from "framer-motion";
import { Wand2, Image, Video, Lightbulb } from "lucide-react";

const suggestions = [
  { icon: Wand2, text: "Generate a futuristic city", action: "Generate an image of a futuristic city at night with neon lights and flying cars" },
  { icon: Image, text: "Transform into superhero", action: "I want to transform my photo into a superhero character. How can I do that?" },
  { icon: Video, text: "Create video from image", action: "Can you help me create a short video from my photo?" },
  { icon: Lightbulb, text: "Business idea for 2026", action: "Give me an innovative business idea for 2026 using AI technology" },
];

interface SuggestedActionsProps { onSelect: (text: string) => void; }

export function SuggestedActions({ onSelect }: SuggestedActionsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-8 max-w-lg mx-auto">
      {suggestions.map((item, index) => (
        <motion.button key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}
          onClick={() => onSelect(item.action)} className="flex items-center gap-3 p-4 glass-card hover:bg-white/10 transition-all duration-300 text-left group">
          <div className="w-10 h-10 rounded-lg bg-nexus-600/30 flex items-center justify-center group-hover:bg-nexus-600/50 transition-colors">
            <item.icon className="w-5 h-5 text-nexus-400" />
          </div>
          <span className="text-sm text-white/80 group-hover:text-white transition-colors">{item.text}</span>
        </motion.button>
      ))}
    </div>
  );
}