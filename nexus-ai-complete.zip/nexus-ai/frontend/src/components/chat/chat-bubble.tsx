"use client";

import { motion } from "framer-motion";
import { ChatMessage } from "@/types";
import { User, Bot, Volume2, Download } from "lucide-react";
import ReactMarkdown from "react-markdown";

interface ChatBubbleProps { message: ChatMessage; isLatest: boolean; }

export function ChatBubble({ message, isLatest }: ChatBubbleProps) {
  const isUser = message.role === "USER";
  return (
    <motion.div initial={{ opacity: 0, y: 10, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.3 }}
      className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={`flex gap-3 max-w-[80%] ${isUser ? "flex-row-reverse" : "flex-row"}`}>
        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${isUser ? "bg-nexus-600" : "bg-gradient-to-br from-nexus-500 to-accent-cyan"}`}>
          {isUser ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
        </div>
        <div className="space-y-2">
          <div className={`px-4 py-3 rounded-2xl ${isUser ? "bg-nexus-600/90 text-white rounded-br-sm" : "glass-card text-white/90 rounded-bl-sm"}`}>
            <ReactMarkdown className="prose prose-invert prose-sm max-w-none"
              components={{ code: ({ children }) => <code className="bg-black/30 px-1 py-0.5 rounded text-sm font-mono">{children}</code> }}>
              {message.content}
            </ReactMarkdown>
          </div>
          {!isUser && (
            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              {message.audioUrl && (
                <button onClick={() => { const audio = new Audio(message.audioUrl); audio.play(); }}
                  className="p-1.5 rounded-lg bg-white/5 text-white/60 hover:bg-white/10 transition-colors">
                  <Volume2 className="w-4 h-4" />
                </button>
              )}
              <button className="p-1.5 rounded-lg bg-white/5 text-white/60 hover:bg-white/10 transition-colors">
                <Download className="w-4 h-4" />
              </button>
              {message.sentiment && (
                <span className="text-xs text-white/40 px-2 py-1 rounded-full bg-white/5">{message.sentiment}</span>
              )}
            </div>
          )}
          <span className="text-xs text-white/30">{new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
        </div>
      </div>
    </motion.div>
  );
}