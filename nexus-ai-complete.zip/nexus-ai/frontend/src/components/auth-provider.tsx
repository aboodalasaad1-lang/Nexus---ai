"use client";

import { createContext, useContext, ReactNode } from "react";
import { useAuthStore } from "@/store/auth-store";

const AuthContext = createContext(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const auth = useAuthStore();
  return <AuthContext.Provider value={auth}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}