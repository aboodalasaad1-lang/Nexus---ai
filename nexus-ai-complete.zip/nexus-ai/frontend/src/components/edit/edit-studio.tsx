"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useDropzone } from "react-dropzone";
import { Wand2, Eraser, Maximize, Shirt, Merge, Sparkles, Film, Image as ImageIcon, Download, Loader2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import toast from "react-hot-toast";
import Image from "next/image";

const tools = [
  { id: "remove-bg", name: "Remove Background", icon: Eraser, tier: "free", description: "AI-powered background removal", credits: 0 },
  { id: "enhance", name: "Enhance 4K", icon: Maximize, tier: "free", description: "Upscale and enhance quality", credits: 0 },
  { id: "lighting", name: "Fix Lighting", icon: Sparkles, tier: "free", description: "Professional lighting correction", credits: 0 },
  { id: "change-clothes", name: "Change Clothes", icon: Shirt, tier: "pro", description: "Virtual outfit try-on", credits: 5 },
  { id: "change-place", name: "Change Location", icon: ImageIcon, tier: "pro", description: "Transport to any background", credits: 5 },
  { id: "merge", name: "Merge Photos", icon: Merge, tier: "pro", description: "Combine multiple images", credits: 8 },
  { id: "face-enhance", name: "Face Enhancement", icon: Sparkles, tier: "pro", description: "Professional retouching", credits: 5 },
  { id: "cinematic", name: "Cinematic Effects", icon: Film, tier: "premium", description: "Movie-grade color grading", credits: 10 },
  { id: "animate", name: "Animate Photo", icon: Film, tier: "premium", description: "Bring photos to life", credits: 15 },
  { id: "ad", name: "Create Ad", icon: Sparkles, tier: "premium", description: "Convert to advertisement", credits: 12 },
];

export function EditStudio() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const onDrop = (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => setUploadedImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const { getRootProps, getInputProps } = useDropzone({ onDrop, accept: { "image/*": [] } });

  const processImage = useMutation({
    mutationFn: async () => {
      const response = await api.post("/edit/process", { image: uploadedImage, tool: selectedTool });
      return response.data;
    },
    onSuccess: (data) => { setResultImage(data.imageUrl); setIsProcessing(false); toast.success("Image processed successfully!"); },
    onError: () => { setIsProcessing(false); toast.error("Processing failed. Please try again."); },
  });

  const handleProcess = () => {
    if (!uploadedImage || !selectedTool) { toast.error("Please upload an image and select a tool"); return; }
    setIsProcessing(true);
    processImage.mutate();
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case "free": return "bg-green-500/20 text-green-400 border-green-500/30";
      case "pro": return "bg-nexus-500/20 text-nexus-400 border-nexus-500/30";
      case "premium": return "bg-amber-500/20 text-amber-400 border-amber-500/30";
      default: return "bg-white/10 text-white/60";
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-1 space-y-4">
        <h3 className="text-lg font-semibold text-white mb-4">Editing Tools</h3>
        <div className="space-y-2">
          {tools.map((tool) => (
            <button key={tool.id} onClick={() => setSelectedTool(tool.id)}
              className={`w-full glass-card p-4 rounded-xl text-left transition-all duration-300 flex items-center gap-3 ${selectedTool === tool.id ? "ring-2 ring-nexus-500 bg-nexus-500/10" : "hover:bg-white/5"}`}>
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getTierColor(tool.tier)}`}>
                <tool.icon className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-white font-medium text-sm">{tool.name}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full border ${getTierColor(tool.tier)}`}>{tool.tier}</span>
                </div>
                <p className="text-white/40 text-xs mt-0.5">{tool.description}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
      <div className="lg:col-span-2">
        <div className="glass-card p-6 rounded-3xl h-full">
          {!uploadedImage ? (
            <div {...getRootProps()} className="border-2 border-dashed border-white/20 rounded-2xl p-16 text-center cursor-pointer hover:border-white/40 transition-colors">
              <input {...getInputProps()} />
              <ImageIcon className="w-12 h-12 mx-auto mb-4 text-white/40" />
              <p className="text-white/60">Drop your image here or click to browse</p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="relative aspect-video rounded-xl overflow-hidden bg-white/5">
                <Image src={uploadedImage} alt="Original" fill className="object-contain" />
              </div>
              <div className="flex justify-center">
                <button onClick={handleProcess} disabled={isProcessing || !selectedTool}
                  className="glow-button inline-flex items-center gap-2 disabled:opacity-50">
                  {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5" />}
                  {isProcessing ? "Processing..." : "Apply Effect"}
                </button>
              </div>
              {resultImage && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative aspect-video rounded-xl overflow-hidden bg-white/5">
                  <Image src={resultImage} alt="Result" fill className="object-contain" />
                  <button className="absolute bottom-4 right-4 p-2 bg-nexus-600 rounded-lg hover:bg-nexus-500 transition-colors">
                    <Download className="w-5 h-5 text-white" />
                  </button>
                </motion.div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}