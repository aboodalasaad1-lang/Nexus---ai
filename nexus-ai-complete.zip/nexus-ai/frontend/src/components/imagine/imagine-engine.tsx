"use client";

import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useDropzone } from "react-dropzone";
import { Upload, Wand2, Download, Share2, Clock, Zap } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import toast from "react-hot-toast";
import Image from "next/image";

const personas = [
  { id: "millionaire", name: "Millionaire Life", icon: "💰", credits: 5, description: "Luxury lifestyle, private jets, yachts" },
  { id: "football", name: "Football Star", icon: "⚽", credits: 5, description: "Stadium lights, championship glory" },
  { id: "actor", name: "Hollywood Actor", icon: "🎬", credits: 5, description: "Red carpet, movie premiere" },
  { id: "astronaut", name: "Astronaut", icon: "🚀", credits: 5, description: "Space exploration, Mars mission" },
  { id: "royal", name: "King / Royal", icon: "👑", credits: 5, description: "Royal palace, crown and throne" },
  { id: "luxury", name: "Luxury Lifestyle", icon: "🏎️", credits: 5, description: "Supercars, mansions, parties" },
  { id: "superhero", name: "Superhero", icon: "🦸", credits: 5, description: "Super powers, saving the world" },
  { id: "fantasy", name: "Fantasy World", icon: "🧙", credits: 5, description: "Magic, dragons, enchanted forests" },
];

const timeTravel = [
  { id: "future30", name: "30 Years Later", icon: "🔮", credits: 8 },
  { id: "past1920", name: "1920s Vintage", icon: "📜", credits: 8 },
  { id: "future2050", name: "Year 2050", icon: "🌟", credits: 8 },
  { id: "renaissance", name: "Renaissance", icon: "🎨", credits: 8 },
];

export function ImagineEngine() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [selectedPersona, setSelectedPersona] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => setUploadedImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop, accept: { "image/*": [] }, maxFiles: 1 });

  const generateImage = useMutation({
    mutationFn: async () => {
      const response = await api.post("/imagine/generate", { image: uploadedImage, persona: selectedPersona, timeTravel: selectedTime });
      return response.data;
    },
    onSuccess: (data) => {
      setGeneratedImages((prev) => [...prev, data.imageUrl]);
      setIsGenerating(false);
      toast.success("Image generated successfully!");
    },
    onError: () => { setIsGenerating(false); toast.error("Failed to generate image. Please try again."); },
  });

  const handleGenerate = () => {
    if (!uploadedImage) { toast.error("Please upload a photo first"); return; }
    if (!selectedPersona && !selectedTime) { toast.error("Please select a persona or time travel option"); return; }
    setIsGenerating(true);
    generateImage.mutate();
  };

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-8 rounded-3xl">
        <div {...getRootProps()} className={`border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all duration-300 ${isDragActive ? "border-nexus-500 bg-nexus-500/10" : "border-white/20 hover:border-white/40"}`}>
          <input {...getInputProps()} />
          {uploadedImage ? (
            <div className="relative w-48 h-48 mx-auto">
              <Image src={uploadedImage} alt="Uploaded" fill className="object-cover rounded-2xl" />
              <button onClick={(e) => { e.stopPropagation(); setUploadedImage(null); }}
                className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white">×</button>
            </div>
          ) : (
            <>
              <Upload className="w-12 h-12 mx-auto mb-4 text-white/40" />
              <p className="text-white/60 mb-2">Drop your photo here or click to browse</p>
              <p className="text-white/40 text-sm">Supports JPG, PNG, WEBP up to 10MB</p>
            </>
          )}
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2"><Zap className="w-5 h-5 text-nexus-400" />Choose Your Persona</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {personas.map((persona) => (
            <button key={persona.id} onClick={() => setSelectedPersona(selectedPersona === persona.id ? null : persona.id)}
              className={`glass-card p-4 rounded-xl text-left transition-all duration-300 ${selectedPersona === persona.id ? "ring-2 ring-nexus-500 bg-nexus-500/20" : "hover:bg-white/10"}`}>
              <div className="text-3xl mb-2">{persona.icon}</div>
              <div className="font-medium text-white text-sm">{persona.name}</div>
              <div className="text-white/40 text-xs mt-1">{persona.credits} credits</div>
            </button>
          ))}
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2"><Clock className="w-5 h-5 text-accent-cyan" />Time Travel</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {timeTravel.map((time) => (
            <button key={time.id} onClick={() => setSelectedTime(selectedTime === time.id ? null : time.id)}
              className={`glass-card p-4 rounded-xl text-left transition-all duration-300 ${selectedTime === time.id ? "ring-2 ring-accent-cyan bg-accent-cyan/20" : "hover:bg-white/10"}`}>
              <div className="text-3xl mb-2">{time.icon}</div>
              <div className="font-medium text-white text-sm">{time.name}</div>
              <div className="text-white/40 text-xs mt-1">{time.credits} credits</div>
            </button>
          ))}
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-center">
        <button onClick={handleGenerate} disabled={isGenerating || !uploadedImage}
          className="glow-button text-lg px-8 py-4 disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center gap-3">
          {isGenerating ? (
            <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />Generating...</>
          ) : (
            <><Wand2 className="w-5 h-5" />Generate Magic</>
          )}
        </button>
      </motion.div>

      <AnimatePresence>
        {generatedImages.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="glass-card p-6 rounded-3xl">
            <h3 className="text-xl font-semibold text-white mb-4">Your Creations</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {generatedImages.map((img, index) => (
                <motion.div key={index} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: index * 0.1 }} className="relative group">
                  <div className="aspect-square rounded-xl overflow-hidden bg-white/5">
                    <Image src={img} alt={`Generated ${index + 1}`} fill className="object-cover" />
                  </div>
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-center justify-center gap-3">
                    <button className="p-2 bg-white/20 rounded-lg hover:bg-white/30 transition-colors"><Download className="w-5 h-5 text-white" /></button>
                    <button className="p-2 bg-white/20 rounded-lg hover:bg-white/30 transition-colors"><Share2 className="w-5 h-5 text-white" /></button>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}