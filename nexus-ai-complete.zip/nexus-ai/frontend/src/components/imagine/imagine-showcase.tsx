"use client";

import { motion } from "framer-motion";
import { Star } from "lucide-react";

const examples = [
  { persona: "Millionaire", likes: 2341 },
  { persona: "Superhero", likes: 1892 },
  { persona: "Astronaut", likes: 3156 },
];

export function ImagineShowcase() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {examples.map((example, index) => (
        <motion.div key={index} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.2 }}
          className="glass-card rounded-2xl overflow-hidden group cursor-pointer">
          <div className="relative aspect-[4/5] overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10" />
            <div className="absolute inset-0 flex">
              <div className="w-1/2 border-r border-white/10 relative">
                <div className="absolute top-2 left-2 z-20 bg-black/50 px-2 py-1 rounded text-xs text-white/80">Before</div>
              </div>
              <div className="w-1/2 relative">
                <div className="absolute top-2 right-2 z-20 bg-nexus-600/80 px-2 py-1 rounded text-xs text-white">After</div>
              </div>
            </div>
            <div className="absolute bottom-4 left-4 right-4 z-20">
              <div className="flex items-center justify-between">
                <span className="text-white font-semibold">{example.persona}</span>
                <div className="flex items-center gap-1 text-white/80">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm">{example.likes}</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}