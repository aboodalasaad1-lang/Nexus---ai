"use client";

import { motion } from "framer-motion";
import { Bot, Wand2, Paintbrush, Flame, Users, Gem } from "lucide-react";
import Link from "next/link";

const features = [
  { icon: Bot, title: "AI Companion", description: "Intelligent chatbot with emotional intelligence, memory, and voice. Available 24/7 in 50+ languages.", href: "/chat", color: "from-nexus-500 to-nexus-600" },
  { icon: Wand2, title: "Imagine", description: "Transform into 8+ personas. Time travel, become a superhero, or live the luxury life.", href: "/imagine", color: "from-accent-cyan to-nexus-500" },
  { icon: Paintbrush, title: "Edit Studio", description: "Professional AI editing tools. Remove backgrounds, enhance 4K, change clothes, cinematic effects.", href: "/edit", color: "from-purple-500 to-nexus-500" },
  { icon: Flame, title: "Challenges", description: "Viral before/after challenges. Invite friends, earn credits, climb the leaderboard.", href: "/community", color: "from-orange-500 to-red-500" },
  { icon: Users, title: "Community", description: "Share creations, get likes, comment, and discover trending AI art from creators worldwide.", href: "/community", color: "from-green-500 to-accent-cyan" },
  { icon: Gem, title: "AI Twin", description: "Create your digital twin. Same face, voice, and personality. The ultimate AI experience.", href: "/pricing", color: "from-amber-500 to-orange-500" },
];

export function FeaturesGrid() {
  return (
    <section className="py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <h2 className="section-title">Everything You Need</h2>
          <p className="text-white/60 max-w-2xl mx-auto">One platform, infinite possibilities. From intelligent conversations to creative masterpieces.</p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div key={feature.title} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }}>
              <Link href={feature.href}>
                <div className="feature-card h-full">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4`}>
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                  <p className="text-white/60 text-sm">{feature.description}</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}