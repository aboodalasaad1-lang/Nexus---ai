/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",
  images: { domains: ["nexus-ai-cdn.com", "s3.amazonaws.com", "cloudfront.net"], unoptimized: true },
  experimental: { ppr: true },
  async headers() {
    return [{
      source: "/api/:path*",
      headers: [
        { key: "Access-Control-Allow-Origin", value: "*" },
        { key: "Access-Control-Allow-Methods", value: "GET,POST,PUT,DELETE,OPTIONS" },
        { key: "Access-Control-Allow-Headers", value: "Content-Type, Authorization" },
      ],
    }];
  },
};
module.exports = nextConfig;