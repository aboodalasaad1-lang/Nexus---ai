import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { AppError } from "./error";

export interface AuthRequest extends Request {
  user?: { id: string; email: string; plan: string };
}

export function authenticate(req: AuthRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    throw new AppError("Unauthorized - No token provided", 401);
  }
  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "nexus-ai-secret") as any;
    req.user = decoded;
    next();
  } catch (error) {
    throw new AppError("Unauthorized - Invalid token", 401);
  }
}

export function requirePlan(plans: string[]) {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    if (!req.user) throw new AppError("Unauthorized", 401);
    if (!plans.includes(req.user.plan)) {
      throw new AppError(`This feature requires ${plans.join(" or ")} plan`, 403);
    }
    next();
  };
}

export function requireCredits(amount: number) {
  return async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
    if (!req.user) throw new AppError("Unauthorized", 401);
    next();
  };
}