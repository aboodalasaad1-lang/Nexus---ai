import Redis from "ioredis";
import { logger } from "@/utils/logger";

let redis: Redis;

export async function connectRedis(): Promise<Redis> {
  redis = new Redis({
    host: process.env.REDIS_HOST || "localhost",
    port: parseInt(process.env.REDIS_PORT || "6379"),
    password: process.env.REDIS_PASSWORD,
    maxRetriesPerRequest: 3,
    retryStrategy: (times) => Math.min(times * 50, 2000),
  });

  redis.on("connect", () => logger.info("Redis connected"));
  redis.on("error", (err) => logger.error("Redis error:", err));
  redis.on("reconnecting", () => logger.warn("Redis reconnecting..."));

  return redis;
}

export function getRedis(): Redis {
  if (!redis) throw new Error("Redis not initialized. Call connectRedis() first.");
  return redis;
}

export async function cacheSet(key: string, value: any, ttl: number = 3600): Promise<void> {
  await getRedis().setex(key, ttl, JSON.stringify(value));
}

export async function cacheGet<T>(key: string): Promise<T | null> {
  const data = await getRedis().get(key);
  return data ? JSON.parse(data) : null;
}

export async function cacheDelete(key: string): Promise<void> {
  await getRedis().del(key);
}