import { Router } from "express";
import { EditController } from "@/controllers/edit.controller";
import { authenticate, requireCredits } from "@/middleware/auth";
const router = Router();
router.use(authenticate);
router.post("/process", requireCredits(0), EditController.process);
router.get("/tools", EditController.getTools);
router.get("/history", EditController.getHistory);
export { router as editRouter };