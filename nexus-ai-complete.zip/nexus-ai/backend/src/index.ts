import express from "express";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import dotenv from "dotenv";
import { createServer } from "http";
import { Server } from "socket.io";
import rateLimit from "express-rate-limit";

import { authRouter } from "./routes/auth.routes";
import { chatRouter } from "./routes/chat.routes";
import { imagineRouter } from "./routes/imagine.routes";
import { editRouter } from "./routes/edit.routes";
import { videoRouter } from "./routes/video.routes";
import { paymentRouter } from "./routes/payment.routes";
import { communityRouter } from "./routes/community.routes";
import { userRouter } from "./routes/user.routes";
import { errorHandler } from "./middleware/error";
import { logger } from "./utils/logger";
import { connectRedis } from "./lib/redis";

dotenv.config();

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: process.env.FRONTEND_URL || "http://localhost:3000", credentials: true },
});

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      connectSrc: ["'self'", "https://api.openai.com", "https://api.elevenlabs.io"],
    },
  },
}));

app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:3000",
  credentials: true,
}));

app.use(compression());
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: { error: "Too many requests, please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use("/api/", limiter);

// Stricter rate limits for AI endpoints
const aiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10,
  message: { error: "AI rate limit exceeded. Please wait a moment." },
});
app.use("/api/chat", aiLimiter);
app.use("/api/imagine", aiLimiter);
app.use("/api/video", aiLimiter);

// Health check
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString(), version: "1.0.0" });
});

// API Routes
app.use("/api/auth", authRouter);
app.use("/api/chat", chatRouter);
app.use("/api/imagine", imagineRouter);
app.use("/api/edit", editRouter);
app.use("/api/video", videoRouter);
app.use("/api/payments", paymentRouter);
app.use("/api/community", communityRouter);
app.use("/api/user", userRouter);

// WebSocket handling
io.on("connection", (socket) => {
  logger.info(`Client connected: ${socket.id}`);

  socket.on("join-chat", (chatId: string) => {
    socket.join(chatId);
    logger.info(`Socket ${socket.id} joined chat ${chatId}`);
  });

  socket.on("typing", (data: { chatId: string; userId: string }) => {
    socket.to(data.chatId).emit("user-typing", { userId: data.userId });
  });

  socket.on("disconnect", () => {
    logger.info(`Client disconnected: ${socket.id}`);
  });
});

// Error handling
app.use(errorHandler);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

const PORT = process.env.PORT || 3001;

async function startServer() {
  try {
    await connectRedis();
    logger.info("Redis connected successfully");

    httpServer.listen(PORT, () => {
      logger.info(`🚀 Nexus AI Server running on port ${PORT}`);
      logger.info(`📡 Environment: ${process.env.NODE_ENV || "development"}`);
    });
  } catch (error) {
    logger.error("Failed to start server:", error);
    process.exit(1);
  }
}

startServer();

export { io };