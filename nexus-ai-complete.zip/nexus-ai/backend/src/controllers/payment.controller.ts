import { Request, Response } from "express";
import { PaymentService } from "@/services/payment.service";
import { AuthRequest } from "@/middleware/auth";
import { logger } from "@/utils/logger";
import { AppError } from "@/middleware/error";

export class PaymentController {
  static async getPlans(req: Request, res: Response): Promise<void> {
    const plans = PaymentService.getPlans();
    res.json(plans);
  }

  static async createSubscription(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { planId, paymentMethod } = req.body;
      const result = await PaymentService.createSubscription(userId, planId, paymentMethod);
      res.json(result);
    } catch (error: any) {
      logger.error("Subscription error:", error);
      throw new AppError(error.message || "Subscription failed", 500);
    }
  }

  static async buyCredits(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { amount, paymentMethod } = req.body;
      const result = await PaymentService.buyCredits(userId, amount, paymentMethod);
      res.json(result);
    } catch (error: any) {
      throw new AppError(error.message || "Credit purchase failed", 500);
    }
  }

  static async getPaymentHistory(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const history = await PaymentService.getPaymentHistory(userId);
      res.json(history);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get history", 500);
    }
  }

  static async stripeWebhook(req: Request, res: Response): Promise<void> {
    try {
      const signature = req.headers["stripe-signature"] as string;
      await PaymentService.handleStripeWebhook(req.body, signature);
      res.json({ received: true });
    } catch (error: any) {
      logger.error("Stripe webhook error:", error);
      throw new AppError(error.message || "Webhook processing failed", 400);
    }
  }

  static async paypalWebhook(req: Request, res: Response): Promise<void> {
    try {
      await PaymentService.handlePaypalWebhook(req.body);
      res.json({ received: true });
    } catch (error: any) {
      logger.error("PayPal webhook error:", error);
      throw new AppError(error.message || "Webhook processing failed", 400);
    }
  }
}