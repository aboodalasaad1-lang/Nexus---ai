import { Request, Response } from "express";
import { ImagineService } from "@/services/imagine.service";
import { AuthRequest } from "@/middleware/auth";
import { logger } from "@/utils/logger";
import { AppError } from "@/middleware/error";

export class ImagineController {
  static async generate(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { image, persona, timeTravel } = req.body;
      const result = await ImagineService.generate(userId, image, persona, timeTravel);
      res.json(result);
    } catch (error: any) {
      logger.error("Imagine generation error:", error);
      throw new AppError(error.message || "Image generation failed", 500);
    }
  }

  static async getPersonas(req: Request, res: Response): Promise<void> {
    const personas = ImagineService.getPersonas();
    res.json(personas);
  }

  static async getHistory(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const history = await ImagineService.getHistory(userId);
      res.json(history);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get history", 500);
    }
  }

  static async deleteImage(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { imageId } = req.params;
      await ImagineService.deleteImage(userId, imageId);
      res.json({ message: "Image deleted" });
    } catch (error: any) {
      throw new AppError(error.message || "Failed to delete image", 500);
    }
  }
}