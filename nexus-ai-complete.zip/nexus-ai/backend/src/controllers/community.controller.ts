import { Request, Response } from "express";
import { CommunityService } from "@/services/community.service";
import { AuthRequest } from "@/middleware/auth";
import { logger } from "@/utils/logger";
import { AppError } from "@/middleware/error";

export class CommunityController {
  static async getFeed(req: Request, res: Response): Promise<void> {
    try {
      const { page = 1, limit = 20, sort = "trending" } = req.query;
      const feed = await CommunityService.getFeed(Number(page), Number(limit), sort as string);
      res.json(feed);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get feed", 500);
    }
  }

  static async getLeaderboard(req: Request, res: Response): Promise<void> {
    try {
      const { period = "weekly" } = req.query;
      const leaderboard = await CommunityService.getLeaderboard(period as string);
      res.json(leaderboard);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get leaderboard", 500);
    }
  }

  static async getPost(req: Request, res: Response): Promise<void> {
    try {
      const { postId } = req.params;
      const post = await CommunityService.getPost(postId);
      res.json(post);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get post", 500);
    }
  }

  static async createPost(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { imageUrl, title, persona } = req.body;
      const post = await CommunityService.createPost(userId, imageUrl, title, persona);
      res.status(201).json(post);
    } catch (error: any) {
      logger.error("Create post error:", error);
      throw new AppError(error.message || "Failed to create post", 500);
    }
  }

  static async likePost(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { postId } = req.params;
      const result = await CommunityService.likePost(userId, postId);
      res.json(result);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to like post", 500);
    }
  }

  static async addComment(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { postId } = req.params;
      const { content } = req.body;
      const comment = await CommunityService.addComment(userId, postId, content);
      res.status(201).json(comment);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to add comment", 500);
    }
  }

  static async deletePost(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { postId } = req.params;
      await CommunityService.deletePost(userId, postId);
      res.json({ message: "Post deleted" });
    } catch (error: any) {
      throw new AppError(error.message || "Failed to delete post", 500);
    }
  }
}