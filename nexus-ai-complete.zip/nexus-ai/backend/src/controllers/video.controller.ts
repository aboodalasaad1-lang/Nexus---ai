import { Request, Response } from "express";
import { VideoService } from "@/services/video.service";
import { AuthRequest } from "@/middleware/auth";
import { logger } from "@/utils/logger";
import { AppError } from "@/middleware/error";

export class VideoController {
  static async generate(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { prompt, duration, style } = req.body;
      const result = await VideoService.generate(userId, prompt, duration, style);
      res.json(result);
    } catch (error: any) {
      logger.error("Video generation error:", error);
      throw new AppError(error.message || "Video generation failed", 500);
    }
  }

  static async generateFromImage(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { image, prompt } = req.body;
      const result = await VideoService.generateFromImage(userId, image, prompt);
      res.json(result);
    } catch (error: any) {
      logger.error("Video from image error:", error);
      throw new AppError(error.message || "Video generation failed", 500);
    }
  }

  static async getUserVideos(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const videos = await VideoService.getUserVideos(userId);
      res.json(videos);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get videos", 500);
    }
  }

  static async deleteVideo(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { videoId } = req.params;
      await VideoService.deleteVideo(userId, videoId);
      res.json({ message: "Video deleted" });
    } catch (error: any) {
      throw new AppError(error.message || "Failed to delete video", 500);
    }
  }
}