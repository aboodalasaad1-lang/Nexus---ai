import { Request, Response } from "express";
import { UserService } from "@/services/user.service";
import { AuthRequest } from "@/middleware/auth";
import { logger } from "@/utils/logger";
import { AppError } from "@/middleware/error";

export class UserController {
  static async getProfile(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const profile = await UserService.getProfile(userId);
      res.json(profile);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get profile", 500);
    }
  }

  static async updateProfile(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const updates = req.body;
      const profile = await UserService.updateProfile(userId, updates);
      res.json(profile);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to update profile", 500);
    }
  }

  static async getCredits(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const credits = await UserService.getCredits(userId);
      res.json(credits);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get credits", 500);
    }
  }

  static async getStats(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const stats = await UserService.getStats(userId);
      res.json(stats);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get stats", 500);
    }
  }

  static async getReferrals(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const referrals = await UserService.getReferrals(userId);
      res.json(referrals);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get referrals", 500);
    }
  }

  static async claimReferralReward(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const result = await UserService.claimReferralReward(userId);
      res.json(result);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to claim reward", 500);
    }
  }
}