import { Request, Response } from "express";
import { AuthService } from "@/services/auth.service";
import { logger } from "@/utils/logger";
import { AppError } from "@/middleware/error";

export class AuthController {
  static async register(req: Request, res: Response): Promise<void> {
    try {
      const { email, password, name } = req.body;
      const result = await AuthService.register(email, password, name);
      res.status(201).json(result);
    } catch (error: any) {
      logger.error("Registration error:", error);
      throw new AppError(error.message || "Registration failed", 400);
    }
  }

  static async login(req: Request, res: Response): Promise<void> {
    try {
      const { email, password } = req.body;
      const result = await AuthService.login(email, password);
      res.json(result);
    } catch (error: any) {
      logger.error("Login error:", error);
      throw new AppError(error.message || "Invalid credentials", 401);
    }
  }

  static async logout(req: Request, res: Response): Promise<void> {
    res.json({ message: "Logged out successfully" });
  }

  static async refreshToken(req: Request, res: Response): Promise<void> {
    try {
      const { refreshToken } = req.body;
      const result = await AuthService.refreshToken(refreshToken);
      res.json(result);
    } catch (error: any) {
      throw new AppError(error.message || "Token refresh failed", 401);
    }
  }

  static async forgotPassword(req: Request, res: Response): Promise<void> {
    try {
      const { email } = req.body;
      await AuthService.forgotPassword(email);
      res.json({ message: "Password reset email sent" });
    } catch (error: any) {
      throw new AppError(error.message || "Failed to send reset email", 400);
    }
  }

  static async resetPassword(req: Request, res: Response): Promise<void> {
    try {
      const { token, password } = req.body;
      await AuthService.resetPassword(token, password);
      res.json({ message: "Password reset successful" });
    } catch (error: any) {
      throw new AppError(error.message || "Password reset failed", 400);
    }
  }

  static async verifyEmail(req: Request, res: Response): Promise<void> {
    try {
      const { token } = req.params;
      await AuthService.verifyEmail(token);
      res.json({ message: "Email verified successfully" });
    } catch (error: any) {
      throw new AppError(error.message || "Email verification failed", 400);
    }
  }
}