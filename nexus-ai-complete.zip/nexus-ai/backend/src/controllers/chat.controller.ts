import { Request, Response } from "express";
import { ChatService } from "@/services/chat.service";
import { AuthRequest } from "@/middleware/auth";
import { logger } from "@/utils/logger";
import { AppError } from "@/middleware/error";

export class ChatController {
  static async sendMessage(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { content, chatId, voiceEnabled, voiceGender } = req.body;
      const result = await ChatService.processMessage({ content, chatId, voiceEnabled, voiceGender }, userId);
      res.json(result);
    } catch (error: any) {
      logger.error("Chat error:", error);
      throw new AppError(error.message || "Failed to process message", 500);
    }
  }

  static async getHistory(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { chatId } = req.params;
      const history = await ChatService.getHistory(userId, chatId);
      res.json(history);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get history", 500);
    }
  }

  static async clearHistory(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { chatId } = req.params;
      await ChatService.clearHistory(userId, chatId);
      res.json({ message: "History cleared" });
    } catch (error: any) {
      throw new AppError(error.message || "Failed to clear history", 500);
    }
  }

  static async getSuggestions(req: AuthRequest, res: Response): Promise<void> {
    try {
      const suggestions = await ChatService.getSuggestions();
      res.json(suggestions);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get suggestions", 500);
    }
  }

  static async generateVoice(req: AuthRequest, res: Response): Promise<void> {
    try {
      const { text, gender } = req.body;
      const audioUrl = await ChatService.generateVoice(text, gender);
      res.json({ audioUrl });
    } catch (error: any) {
      throw new AppError(error.message || "Voice generation failed", 500);
    }
  }
}