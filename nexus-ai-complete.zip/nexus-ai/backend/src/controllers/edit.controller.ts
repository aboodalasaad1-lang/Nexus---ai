import { Request, Response } from "express";
import { EditService } from "@/services/edit.service";
import { AuthRequest } from "@/middleware/auth";
import { logger } from "@/utils/logger";
import { AppError } from "@/middleware/error";

export class EditController {
  static async process(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const { image, tool } = req.body;
      const result = await EditService.process(userId, image, tool);
      res.json(result);
    } catch (error: any) {
      logger.error("Edit processing error:", error);
      throw new AppError(error.message || "Image processing failed", 500);
    }
  }

  static async getTools(req: Request, res: Response): Promise<void> {
    const tools = EditService.getTools();
    res.json(tools);
  }

  static async getHistory(req: AuthRequest, res: Response): Promise<void> {
    try {
      const userId = req.user!.id;
      const history = await EditService.getHistory(userId);
      res.json(history);
    } catch (error: any) {
      throw new AppError(error.message || "Failed to get history", 500);
    }
  }
}