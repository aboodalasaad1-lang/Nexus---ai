export interface ChatMessage {
  id: string;
  role: "USER" | "ASSISTANT";
  content: string;
  sentiment?: string;
  emotion?: string;
  audioUrl?: string;
  createdAt: Date;
}

export interface AIResponse {
  message: ChatMessage;
  chatId: string;
  tokensUsed: number;
  model: string;
  suggestedActions: string[];
}

export interface SendMessageRequest {
  content: string;
  chatId: string;
  voiceEnabled?: boolean;
  voiceGender?: "male" | "female";
}

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  credits: number;
  plan: "free" | "pro" | "premium";
  createdAt: Date;
}

export interface ImagineRequest {
  image: string;
  persona?: string;
  timeTravel?: string;
}

export interface EditRequest {
  image: string;
  tool: string;
}

export interface PaymentPlan {
  id: string;
  name: string;
  price: number;
  interval: "month" | "year";
  features: string[];
}

export interface CommunityPost {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  imageUrl: string;
  title: string;
  persona: string;
  likes: number;
  comments: number;
  featured: boolean;
  createdAt: Date;
}