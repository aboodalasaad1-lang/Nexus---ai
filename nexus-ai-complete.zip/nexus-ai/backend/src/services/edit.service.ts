import { PrismaClient } from "@prisma/client";
import { logger } from "@/utils/logger";

const prisma = new PrismaClient();

const TOOLS = [
  { id: "remove-bg", name: "Remove Background", tier: "free", credits: 0, api: "removebg" },
  { id: "enhance", name: "Enhance 4K", tier: "free", credits: 0, api: "upscale" },
  { id: "lighting", name: "Fix Lighting", tier: "free", credits: 0, api: "enhance" },
  { id: "change-clothes", name: "Change Clothes", tier: "pro", credits: 5, api: "inpaint" },
  { id: "change-place", name: "Change Location", tier: "pro", credits: 5, api: "inpaint" },
  { id: "merge", name: "Merge Photos", tier: "pro", credits: 8, api: "merge" },
  { id: "face-enhance", name: "Face Enhancement", tier: "pro", credits: 5, api: "face-enhance" },
  { id: "cinematic", name: "Cinematic Effects", tier: "premium", credits: 10, api: "cinematic" },
  { id: "animate", name: "Animate Photo", tier: "premium", credits: 15, api: "animate" },
  { id: "ad", name: "Create Ad", tier: "premium", credits: 12, api: "ad" },
];

export class EditService {
  static async process(userId: string, image: string, toolId: string) {
    const tool = TOOLS.find(t => t.id === toolId);
    if (!tool) throw new Error("Invalid tool");

    // Call appropriate AI service
    const resultUrl = await this.callEditAPI(image, tool.api);

    // Save to history
    await prisma.editedImage.create({
      data: { userId, originalImage: image, editedImage: resultUrl, tool: toolId },
    });

    // Deduct credits if not free
    if (tool.credits > 0) {
      await prisma.user.update({
        where: { id: userId },
        data: { credits: { decrement: tool.credits } },
      });
    }

    logger.info(`Image edited for user ${userId}: ${toolId}`);
    return { imageUrl: resultUrl, tool: tool.name };
  }

  private static async callEditAPI(image: string, api: string): Promise<string> {
    // Integration with various AI editing APIs
    // remove.bg, Replicate, Runway, etc.
    return `https://nexus-ai-cdn.com/edited/${Date.now()}.png`;
  }

  static getTools() {
    return TOOLS;
  }

  static async getHistory(userId: string) {
    return prisma.editedImage.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
  }
}