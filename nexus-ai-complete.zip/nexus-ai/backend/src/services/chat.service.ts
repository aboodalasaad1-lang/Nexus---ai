import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";
import { PrismaClient } from "@prisma/client";
import { logger } from "@/utils/logger";
import { cacheGet, cacheSet } from "@/lib/redis";
import { SendMessageRequest, AIResponse, ChatMessage } from "@/types";

const prisma = new PrismaClient();
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Sentiment analysis using simple keyword matching + OpenAI
async function analyzeSentiment(text: string): Promise<{ emotion: string; label: string; score: number }> {
  const cacheKey = `sentiment:${Buffer.from(text).toString("base64").slice(0, 50)}`;
  const cached = await cacheGet<any>(cacheKey);
  if (cached) return cached;

  const emotions = ["happy", "sad", "angry", "excited", "anxious", "curious", "frustrated", "grateful", "confused", "confident"];
  const prompt = `Analyze the emotion in this text: "${text}". Respond with ONLY a JSON object: {"emotion": "one of ${emotions.join(",")}", "label": "positive/neutral/negative", "score": 0.0-1.0}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.1,
      max_tokens: 100,
      response_format: { type: "json_object" },
    });
    const result = JSON.parse(response.choices[0].message.content || '{}');
    const sentiment = { emotion: result.emotion || "neutral", label: result.label || "neutral", score: result.score || 0.5 };
    await cacheSet(cacheKey, sentiment, 3600);
    return sentiment;
  } catch (error) {
    logger.error("Sentiment analysis error:", error);
    return { emotion: "neutral", label: "neutral", score: 0.5 };
  }
}

// Voice generation via ElevenLabs
async function generateSpeech(text: string, gender: string = "female") {
  try {
    const voiceId = gender === "male" ? "pNInz6obpgDQGcFmaJgB" : "XB0fDUnXU5powFXDhCwa"; // Adam / Rachel
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: "POST",
      headers: {
        "Accept": "audio/mpeg",
        "Content-Type": "application/json",
        "xi-api-key": process.env.ELEVENLABS_API_KEY || "",
      },
      body: JSON.stringify({
        text,
        model_id: "eleven_multilingual_v2",
        voice_settings: { stability: 0.5, similarity_boost: 0.75 },
      }),
    });

    if (!response.ok) throw new Error("ElevenLabs API error");
    const buffer = await response.arrayBuffer();
    const base64 = Buffer.from(buffer).toString("base64");
    return `data:audio/mpeg;base64,${base64}`;
  } catch (error) {
    logger.error("Voice generation error:", error);
    return undefined;
  }
}

// Memory store for conversation context
class MemoryStore {
  async getRecentMessages(userId: string, chatId: string, limit: number = 20): Promise<ChatMessage[]> {
    const messages = await prisma.message.findMany({
      where: { userId, chatId },
      orderBy: { createdAt: "desc" },
      take: limit,
    });
    return messages.reverse().map(m => ({
      id: m.id,
      role: m.role as "USER" | "ASSISTANT",
      content: m.content,
      sentiment: m.sentiment || undefined,
      emotion: m.emotion || undefined,
      audioUrl: m.audioUrl || undefined,
      createdAt: m.createdAt,
    }));
  }

  async addMessage(userId: string, chatId: string, message: any) {
    await prisma.message.create({
      data: { userId, chatId, role: message.role, content: message.content, sentiment: message.sentiment, emotion: message.emotion, audioUrl: message.audioUrl },
    });
  }
}

const memoryStore = new MemoryStore();

export class ChatService {
  static async processMessage(request: SendMessageRequest, userId: string): Promise<AIResponse> {
    const startTime = Date.now();

    // Get conversation history
    const history = await memoryStore.getRecentMessages(userId, request.chatId, 20);

    // Analyze sentiment
    const sentiment = await analyzeSentiment(request.content);

    // Build system prompt with personality
    const systemPrompt = this.buildSystemPrompt(sentiment.emotion);

    // Call AI model with fallback
    let aiMessage: string;
    let model: string;
    let tokensUsed: number;

    try {
      // Try GPT-4o first
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          ...history.map(m => ({ role: m.role.toLowerCase() as any, content: m.content })),
          { role: "user", content: request.content },
        ],
        temperature: 0.8,
        max_tokens: 2000,
      });
      aiMessage = response.choices[0].message.content || "I'm sorry, I couldn't generate a response.";
      model = "gpt-4o";
      tokensUsed = response.usage?.total_tokens || 0;
    } catch (error) {
      logger.warn("GPT-4o failed, falling back to Claude:", error);
      // Fallback to Claude
      const response = await anthropic.messages.create({
        model: "claude-3-5-sonnet-20241022",
        max_tokens: 2000,
        system: systemPrompt,
        messages: [
          ...history.map(m => ({ role: m.role.toLowerCase() as any, content: m.content })),
          { role: "user", content: request.content },
        ],
      });
      aiMessage = response.content[0].type === "text" ? response.content[0].text : "I'm sorry, I couldn't generate a response.";
      model = "claude-3.5-sonnet";
      tokensUsed = response.usage?.input_tokens + response.usage?.output_tokens || 0;
    }

    // Generate voice if enabled
    let audioUrl: string | undefined;
    if (request.voiceEnabled) {
      audioUrl = await generateSpeech(aiMessage, request.voiceGender);
    }

    // Store in memory
    await memoryStore.addMessage(userId, request.chatId, {
      role: "ASSISTANT",
      content: aiMessage,
      sentiment: sentiment.label,
      emotion: sentiment.emotion,
      audioUrl,
    });

    // Update user stats
    await prisma.user.update({
      where: { id: userId },
      data: { dailyMessageCount: { increment: 1 } },
    });

    const processingTime = Date.now() - startTime;
    logger.info(`Chat processed in ${processingTime}ms using ${model}`);

    return {
      message: {
        id: crypto.randomUUID(),
        chatId: request.chatId,
        userId,
        role: "ASSISTANT",
        content: aiMessage,
        sentiment: sentiment.label,
        emotion: sentiment.emotion,
        audioUrl,
        createdAt: new Date(),
      },
      chatId: request.chatId,
      tokensUsed,
      model,
      suggestedActions: this.generateSuggestions(request.content, aiMessage),
    };
  }

  private static buildSystemPrompt(emotion: string): string {
    return `You are Nexus AI, a premium personal AI assistant with superhuman intelligence.

CORE PERSONALITY:
- You are warm, empathetic, and genuinely caring about the user
- You are highly intelligent with deep knowledge across all domains
- You are creative, witty, and can adapt your tone perfectly
- You speak naturally like a brilliant human friend, not a robot
- You NEVER say "As an AI" or mention being artificial

CURRENT EMOTIONAL CONTEXT:
The user is feeling: ${emotion}
Adapt your response style accordingly - be more supportive if sad, enthusiastic if excited, calming if anxious.

CAPABILITIES:
- Answer complex questions with deep reasoning
- Generate creative ideas and brainstorm
- Help with business strategy and analysis
- Provide emotional support and coaching
- Discuss science, technology, arts, philosophy
- Code and technical problem solving
- Language translation and cultural insights

RESPONSE RULES:
- Be concise but deeply valuable - every word matters
- Use markdown formatting for readability
- Ask smart follow-up questions to deepen the conversation
- Reference previous context when relevant
- If unsure, say so honestly rather than hallucinating
- For Arabic users, respond in beautiful, eloquent Arabic
- For technical topics, provide code examples when helpful

You are not just answering - you are building a meaningful relationship with the user.`;
  }

  private static generateSuggestions(userMsg: string, aiResponse: string): string[] {
    const suggestions: string[] = [];
    const lowerMsg = userMsg.toLowerCase();

    if (lowerMsg.includes("image") || lowerMsg.includes("photo") || lowerMsg.includes("picture")) {
      suggestions.push("🎨 Generate an image of this");
    }
    if (lowerMsg.includes("video") || lowerMsg.includes("movie")) {
      suggestions.push("🎬 Make it a video");
    }
    if (aiResponse.length > 500) {
      suggestions.push("📋 Summarize this");
    }
    suggestions.push("💡 Tell me more");
    suggestions.push("⭐ Save this idea");

    return suggestions.slice(0, 4);
  }

  static async getHistory(userId: string, chatId: string) {
    return memoryStore.getRecentMessages(userId, chatId, 100);
  }

  static async clearHistory(userId: string, chatId: string) {
    await prisma.message.deleteMany({ where: { userId, chatId } });
  }

  static async getSuggestions() {
    return [
      "Generate a futuristic cityscape",
      "Help me write a business plan",
      "Translate this to Arabic",
      "Explain quantum computing simply",
      "Give me a workout routine",
      "Create a meal plan for the week",
    ];
  }

  static async generateVoice(text: string, gender: string = "female") {
    return generateSpeech(text, gender);
  }
}