import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { PrismaClient } from "@prisma/client";
import { logger } from "@/utils/logger";

const prisma = new PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || "nexus-ai-secret";
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || "nexus-ai-refresh-secret";

export class AuthService {
  static async register(email: string, password: string, name: string) {
    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) throw new Error("Email already registered");

    const hashedPassword = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        name,
        plan: "free",
        credits: 20,
        dailyMessageCount: 0,
        monthlyImageCount: 0,
      },
    });

    const token = jwt.sign({ id: user.id, email: user.email, plan: user.plan }, JWT_SECRET, { expiresIn: "7d" });
    const refreshToken = jwt.sign({ id: user.id }, JWT_REFRESH_SECRET, { expiresIn: "30d" });

    logger.info(`User registered: ${email}`);
    return { user: { id: user.id, email: user.email, name: user.name, plan: user.plan, credits: user.credits }, token, refreshToken };
  }

  static async login(email: string, password: string) {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) throw new Error("Invalid credentials");

    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) throw new Error("Invalid credentials");

    const token = jwt.sign({ id: user.id, email: user.email, plan: user.plan }, JWT_SECRET, { expiresIn: "7d" });
    const refreshToken = jwt.sign({ id: user.id }, JWT_REFRESH_SECRET, { expiresIn: "30d" });

    logger.info(`User logged in: ${email}`);
    return { user: { id: user.id, email: user.email, name: user.name, plan: user.plan, credits: user.credits }, token, refreshToken };
  }

  static async refreshToken(refreshToken: string) {
    const decoded = jwt.verify(refreshToken, JWT_REFRESH_SECRET) as any;
    const user = await prisma.user.findUnique({ where: { id: decoded.id } });
    if (!user) throw new Error("User not found");

    const token = jwt.sign({ id: user.id, email: user.email, plan: user.plan }, JWT_SECRET, { expiresIn: "7d" });
    return { token };
  }

  static async forgotPassword(email: string) {
    // Implementation: send reset email via email service
    logger.info(`Password reset requested for: ${email}`);
    return { message: "Reset email sent" };
  }

  static async resetPassword(token: string, password: string) {
    // Implementation: verify token and update password
    logger.info("Password reset completed");
    return { message: "Password updated" };
  }

  static async verifyEmail(token: string) {
    // Implementation: verify email token
    logger.info("Email verified");
    return { message: "Email verified" };
  }
}