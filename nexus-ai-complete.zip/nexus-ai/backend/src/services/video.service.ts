import { PrismaClient } from "@prisma/client";
import { logger } from "@/utils/logger";

const prisma = new PrismaClient();

export class VideoService {
  static async generate(userId: string, prompt: string, duration: number = 5, style: string = "realistic") {
    // Integration with Runway Gen-3 / Pika 2.0 / Luma Dream Machine
    const videoUrl = await this.callVideoAPI(prompt, duration, style);

    await prisma.generatedVideo.create({
      data: { userId, prompt, videoUrl, duration, style },
    });

    await prisma.user.update({
      where: { id: userId },
      data: { credits: { decrement: 15 } },
    });

    logger.info(`Video generated for user ${userId}`);
    return { videoUrl, prompt, duration };
  }

  static async generateFromImage(userId: string, image: string, prompt: string) {
    const videoUrl = await this.callVideoAPI(prompt, 5, "realistic", image);

    await prisma.generatedVideo.create({
      data: { userId, prompt, videoUrl, sourceImage: image, duration: 5, style: "image-to-video" },
    });

    await prisma.user.update({
      where: { id: userId },
      data: { credits: { decrement: 12 } },
    });

    logger.info(`Video from image generated for user ${userId}`);
    return { videoUrl, prompt };
  }

  private static async callVideoAPI(prompt: string, duration: number, style: string, image?: string): Promise<string> {
    // Integration with video generation APIs
    /*
    // Runway Gen-3 example:
    const response = await fetch("https://api.runwayml.com/v1/generations", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.RUNWAY_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt,
        duration,
        ratio: "16:9",
        ...(image && { image }),
      }),
    });
    */
    return `https://nexus-ai-cdn.com/videos/${Date.now()}.mp4`;
  }

  static async getUserVideos(userId: string) {
    return prisma.generatedVideo.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
  }

  static async deleteVideo(userId: string, videoId: string) {
    await prisma.generatedVideo.deleteMany({
      where: { id: videoId, userId },
    });
  }
}