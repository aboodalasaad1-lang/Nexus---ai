import { PrismaClient } from "@prisma/client";
import { logger } from "@/utils/logger";

const prisma = new PrismaClient();

export class CommunityService {
  static async getFeed(page: number = 1, limit: number = 20, sort: string = "trending") {
    const skip = (page - 1) * limit;

    const orderBy: any = sort === "trending" 
      ? [{ likes: "desc" }, { createdAt: "desc" }]
      : sort === "newest"
      ? { createdAt: "desc" }
      : { likes: "desc" };

    const posts = await prisma.communityPost.findMany({
      skip,
      take: limit,
      orderBy,
      include: {
        user: { select: { id: true, name: true, avatar: true } },
        _count: { select: { comments: true, likes: true } },
      },
    });

    return posts;
  }

  static async getLeaderboard(period: string = "weekly") {
    const dateFilter = period === "weekly" 
      ? new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      : period === "monthly"
      ? new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
      : new Date(0);

    const leaders = await prisma.user.findMany({
      where: {
        createdAt: { gte: dateFilter },
      },
      orderBy: { totalLikes: "desc" },
      take: 10,
      select: {
        id: true,
        name: true,
        avatar: true,
        totalLikes: true,
        totalPosts: true,
      },
    });

    return leaders.map((user, index) => ({
      rank: index + 1,
      ...user,
    }));
  }

  static async getPost(postId: string) {
    return prisma.communityPost.findUnique({
      where: { id: postId },
      include: {
        user: { select: { id: true, name: true, avatar: true } },
        comments: {
          include: { user: { select: { id: true, name: true, avatar: true } } },
          orderBy: { createdAt: "desc" },
        },
        _count: { select: { likes: true, comments: true } },
      },
    });
  }

  static async createPost(userId: string, imageUrl: string, title: string, persona: string) {
    const post = await prisma.communityPost.create({
      data: { userId, imageUrl, title, persona },
    });

    await prisma.user.update({
      where: { id: userId },
      data: { totalPosts: { increment: 1 } },
    });

    logger.info(`Post created by user ${userId}: ${title}`);
    return post;
  }

  static async likePost(userId: string, postId: string) {
    const existing = await prisma.like.findUnique({
      where: { userId_postId: { userId, postId } },
    });

    if (existing) {
      await prisma.like.delete({ where: { id: existing.id } });
      await prisma.communityPost.update({
        where: { id: postId },
        data: { likes: { decrement: 1 } },
      });
      await prisma.user.update({
        where: { id: (await prisma.communityPost.findUnique({ where: { id: postId } }))?.userId },
        data: { totalLikes: { decrement: 1 } },
      });
      return { liked: false };
    } else {
      await prisma.like.create({ data: { userId, postId } });
      await prisma.communityPost.update({
        where: { id: postId },
        data: { likes: { increment: 1 } },
      });
      const post = await prisma.communityPost.findUnique({ where: { id: postId } });
      await prisma.user.update({
        where: { id: post?.userId },
        data: { totalLikes: { increment: 1 } },
      });
      return { liked: true };
    }
  }

  static async addComment(userId: string, postId: string, content: string) {
    const comment = await prisma.comment.create({
      data: { userId, postId, content },
    });
    return comment;
  }

  static async deletePost(userId: string, postId: string) {
    await prisma.communityPost.deleteMany({
      where: { id: postId, userId },
    });
  }
}