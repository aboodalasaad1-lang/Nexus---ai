import Stripe from "stripe";
import { PrismaClient } from "@prisma/client";
import { logger } from "@/utils/logger";

const prisma = new PrismaClient();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2024-10-28" });

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: 0,
    interval: "month" as const,
    stripePriceId: null,
    features: ["20 AI messages/day", "3 AI images/month", "Basic editing", "Community access"],
    limits: { messagesPerDay: 20, imagesPerMonth: 3, videosPerMonth: 0 },
  },
  {
    id: "pro",
    name: "Pro",
    price: 9.99,
    interval: "month" as const,
    stripePriceId: process.env.STRIPE_PRO_PRICE_ID,
    features: ["Unlimited messages", "100 AI images/month", "Remove watermark", "AI voice", "All editing tools", "5 videos/month"],
    limits: { messagesPerDay: Infinity, imagesPerMonth: 100, videosPerMonth: 5 },
  },
  {
    id: "premium",
    name: "Premium",
    price: 19.99,
    interval: "month" as const,
    stripePriceId: process.env.STRIPE_PREMIUM_PRICE_ID,
    features: ["Everything in Pro", "500 images/month", "Unlimited videos", "AI Twin", "Custom personas", "API access"],
    limits: { messagesPerDay: Infinity, imagesPerMonth: 500, videosPerMonth: Infinity },
  },
];

const CREDIT_PACKAGES = [
  { id: "small", credits: 100, price: 4.99 },
  { id: "medium", credits: 500, price: 19.99 },
  { id: "large", credits: 2000, price: 69.99 },
  { id: "xl", credits: 10000, price: 299.99 },
];

export class PaymentService {
  static getPlans() {
    return PLANS.map(p => ({
      id: p.id,
      name: p.name,
      price: p.price,
      interval: p.interval,
      features: p.features,
    }));
  }

  static async createSubscription(userId: string, planId: string, paymentMethod: string) {
    const plan = PLANS.find(p => p.id === planId);
    if (!plan) throw new Error("Invalid plan");

    if (plan.price === 0) {
      // Free plan - just update user
      await prisma.user.update({
        where: { id: userId },
        data: { plan: planId, subscriptionStatus: "active" },
      });
      return { success: true, plan: planId };
    }

    // Create Stripe subscription
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user?.stripeCustomerId) {
      const customer = await stripe.customers.create({ email: user?.email });
      await prisma.user.update({
        where: { id: userId },
        data: { stripeCustomerId: customer.id },
      });
    }

    const session = await stripe.checkout.sessions.create({
      customer: user?.stripeCustomerId,
      payment_method_types: ["card"],
      line_items: [{ price: plan.stripePriceId, quantity: 1 }],
      mode: "subscription",
      success_url: `${process.env.FRONTEND_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/payment/cancel`,
      metadata: { userId, planId },
    });

    logger.info(`Subscription initiated for user ${userId}: ${planId}`);
    return { sessionId: session.id, url: session.url };
  }

  static async buyCredits(userId: string, packageId: string, paymentMethod: string) {
    const pkg = CREDIT_PACKAGES.find(p => p.id === packageId);
    if (!pkg) throw new Error("Invalid credit package");

    const user = await prisma.user.findUnique({ where: { id: userId } });

    const session = await stripe.checkout.sessions.create({
      customer: user?.stripeCustomerId,
      payment_method_types: ["card"],
      line_items: [{
        price_data: {
          currency: "usd",
          product_data: { name: `${pkg.credits} Nexus AI Credits` },
          unit_amount: Math.round(pkg.price * 100),
        },
        quantity: 1,
      }],
      mode: "payment",
      success_url: `${process.env.FRONTEND_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/payment/cancel`,
      metadata: { userId, credits: pkg.credits.toString() },
    });

    logger.info(`Credit purchase initiated for user ${userId}: ${pkg.credits} credits`);
    return { sessionId: session.id, url: session.url };
  }

  static async getPaymentHistory(userId: string) {
    return prisma.payment.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
  }

  static async handleStripeWebhook(payload: any, signature: string) {
    const event = stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET || ""
    );

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const { userId, planId, credits } = session.metadata || {};

        if (planId) {
          await prisma.user.update({
            where: { id: userId },
            data: { plan: planId, subscriptionStatus: "active" },
          });
          logger.info(`Subscription activated: ${userId} -> ${planId}`);
        }

        if (credits) {
          await prisma.user.update({
            where: { id: userId },
            data: { credits: { increment: parseInt(credits) } },
          });
          logger.info(`Credits added: ${userId} -> ${credits}`);
        }
        break;
      }

      case "invoice.payment_failed": {
        const session = event.data.object as Stripe.Invoice;
        logger.warn(`Payment failed for customer: ${session.customer}`);
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        const user = await prisma.user.findFirst({
          where: { stripeCustomerId: subscription.customer as string },
        });
        if (user) {
          await prisma.user.update({
            where: { id: user.id },
            data: { plan: "free", subscriptionStatus: "cancelled" },
          });
          logger.info(`Subscription cancelled: ${user.id}`);
        }
        break;
      }
    }
  }

  static async handlePaypalWebhook(payload: any) {
    // PayPal webhook handling
    logger.info("PayPal webhook received", payload);
  }
}