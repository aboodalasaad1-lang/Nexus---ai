import { PrismaClient } from "@prisma/client";
import { logger } from "@/utils/logger";

const prisma = new PrismaClient();

export class UserService {
  static async getProfile(userId: string) {
    return prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        avatar: true,
        plan: true,
        credits: true,
        createdAt: true,
        totalPosts: true,
        totalLikes: true,
      },
    });
  }

  static async updateProfile(userId: string, updates: any) {
    return prisma.user.update({
      where: { id: userId },
      data: updates,
      select: {
        id: true,
        email: true,
        name: true,
        avatar: true,
        plan: true,
        credits: true,
      },
    });
  }

  static async getCredits(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { credits: true, plan: true },
    });
    return user;
  }

  static async getStats(userId: string) {
    const [messageCount, imageCount, videoCount, postCount] = await Promise.all([
      prisma.message.count({ where: { userId } }),
      prisma.generatedImage.count({ where: { userId } }),
      prisma.generatedVideo.count({ where: { userId } }),
      prisma.communityPost.count({ where: { userId } }),
    ]);

    return {
      messages: messageCount,
      images: imageCount,
      videos: videoCount,
      posts: postCount,
    };
  }

  static async getReferrals(userId: string) {
    return prisma.referral.findMany({
      where: { referrerId: userId },
      include: {
        referred: { select: { id: true, name: true, createdAt: true } },
      },
    });
  }

  static async claimReferralReward(userId: string) {
    const referrals = await prisma.referral.count({
      where: { referrerId: userId, rewarded: false },
    });

    if (referrals >= 3) {
      const rewardCredits = referrals >= 10 ? 500 : 100;
      await prisma.user.update({
        where: { id: userId },
        data: { credits: { increment: rewardCredits } },
      });
      await prisma.referral.updateMany({
        where: { referrerId: userId, rewarded: false },
        data: { rewarded: true },
      });
      return { success: true, credits: rewardCredits };
    }

    return { success: false, message: "Need at least 3 referrals to claim reward" };
  }
}